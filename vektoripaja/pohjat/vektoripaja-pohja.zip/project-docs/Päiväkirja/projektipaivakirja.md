# Vektoripaja – projektipäiväkirja

> Kirjoita joka viikon lopussa tämän viikon otsikon alle. Vastaa kolmeen kysymykseen. Tee lopuksi commit ja push.
> Löydät viikon otsikon VS Coden haulla: paina Ctrl+F ja liitä hakuun viikon sivulta kopioitu otsikko.

## Vko 40 – Aloitus: työkalut ja projektin rajaus (28.9.–2.10.2026)
> Kirjaa: Kohtaan Mitä tein ja miten?: agenttipyynnön hinta (alku- ja loppulukema ja erotus). Kohtaan Miksi tein näin?: pakollisen ytimen perustelu yhdellä tai kahdella omalla virkkeellä ja linkki tiedostoon suunnitelma.md. Älä kopioi koko tekstiä tiedostosta. Kohtaan Missä työnäyte on?: repositoryn osoite (Kopioi osoite, issuen numero tai commitin tunnus, kohta Repositoryn osoite) ja nämä näyttömatriisin vaatimukset: käyttää ohjelmointieditoria tai kehitysympäristöä, selvittää kehitystiimin kanssa asiakkaan tarpeet, asettaa kehitystiimin kanssa toteutettavat toiminnot tärkeysjärjestykseen sekä suunnittelee ja arvioi kehitystiimin kanssa tehtävien toteuttamista.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 41 – Työkalut käyttöön: valmis kuutio (5.–9.10.2026)
> Kirjaa: Kirjaa projektipäiväkirjaan, mitä työkaluja otit käyttöön, miten GitHub Copilot auttoi käynnistämisessä ja näkyikö pyörivä kuutio ja mitä ympäristötarkistus, valmis testi sekä itsetesti ilmoittivat. Jos jokin jäi kesken, kirjaa virhe ja kohta, josta jatkat. Viikolla 41 ei ole selitettävää funktiota.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 43 – Piirroksen tuonti (SVG) (19.–23.10.2026)
> Kirjaa: Tämä viikko kestää kaksi kalenteriviikkoa (19.–30.10.): pidä viikkopalaveri molempina viikkoina ja kirjoita kirjaus perjantaina 30.10. Asiakkaiden vastaukset (linkki tiedostoon kysymykset.md), käyttöliittymävaatimus, kirjastojen lisenssit README:ssä, tuonnin kortin issuen numero ja sana Sovittu-kommentti, testien 3–5 tulokset, kansiorakenne, moduulien rajat ja palaverissa sovittu dokumentointitapa (linkki tiedostoon suunnitelma.md), kaksi svgelementsin rajoitetta omalla tiedostolla kokeiltuna (linkki tiedostoon kirjastot.md), tuontifunktio selityspohjalla ja releasen v0.0.43 osoite. Selityspohjaa varten avaa vektoripaja/tuonti.py, paina Ctrl+F, valitse Match Whole Word (Alt+W) ja hae sanat if, for ja while. Kirjoita pohjan Testi-riville testit 3–5. Kopioi kohtaan Missä työnäyte on? pohja Näyttömatriisin vaatimukset viikon kirjaukseen. Lista riittää sellaisenaan: jokaiselle vaatimukselle ei tarvitse kirjoittaa omaa työnäytettä. Pohjassa ovat nämä 12 näyttömatriisin vaatimusta: testaa ohjelman toimintoja · tulkitsee suunnitelmia ja toteuttaa ohjelmiston toimintoja · sopii tehtävistä tiimin muiden jäsenten kanssa · selvittää kehitystiimin kanssa asiakkaan tarpeet · jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi · hyödyntää rajapintoja ja käsittelee tietoa · arvioi ohjelmiston tietoturvaa · käyttää versionhallintaa · julkaisee ohjelman tuotantoympäristöön · selvittää ohjelmistokomponenttikirjaston tarjoamat mahdollisuudet ja rajoitteet · suunnittelee, toteuttaa ja testaa ohjelmiston ohjelmistokomponenttikirjastoa käyttäen · dokumentoi ohjelmiston sovitulla tavalla.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 45 – Piirroksen ryhmistä mallin osiksi (2.–6.11.2026)
> Kirjaa: Tämä viikko kestää kaksi kalenteriviikkoa (2.–13.11.): pidä viikkopalaveri molempina viikkoina ja kirjoita kirjaus perjantaina 13.11. Viikon funktio selityspohjalla: funktio on tiedostossa vektoripaja/hierarkia.py rivillä, joka alkaa sanalla def ja funktion nimellä. Kirjoita selityspohjan Testi-rivi jokaisesta testistä 6, 7 ja 8. Lisäksi valinnan toiminnan perustelu, hierarkian kortin issuen numero, releasen v0.0.45 osoite ja nämä näyttömatriisin vaatimukset: testaa ohjelman toimintoja, käyttää rakenteista ohjelmointia toteutuksissa, tulkitsee suunnitelmia ja toteuttaa käyttöliittymän tai sen osia, sopii tehtävistä tiimin muiden jäsenten kanssa, etsii ratkaisuvaihtoehtoja ja ratkoo ongelmia yhdessä tiimin kanssa, jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi, kehittää ohjelmiston toimintalogiikkaa, käyttää versionhallintaa, julkaisee ohjelman tuotantoympäristöön sekä suunnittelee, toteuttaa ja testaa ohjelmiston ohjelmistokomponenttikirjastoa käyttäen.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 47 – Profiilista pyörähdyskappale (revolve) (16.–20.11.2026)
> Kirjaa: Viikon funktio selityspohjalla: funktio on tiedostossa vektoripaja/revolve.py rivillä, joka alkaa sanalla def ja funktion nimellä. Kirjoita selityspohjan Testi-rivi testeistä 9 ja 11. Lisäksi sovittu valintatapa ja oma hyväksymiskriteeri akselin väärälle puolelle, pyörähdyskappaleen ja segmenttisäätimen korttien issuenumerot, releasen v0.0.47 osoite ja nämä näyttömatriisin vaatimukset: testaa ohjelman toimintoja, tulkitsee suunnitelmia ja toteuttaa ohjelmiston toimintoja, sopii tehtävistä tiimin muiden jäsenten kanssa, etsii ratkaisuvaihtoehtoja ja ratkoo ongelmia yhdessä tiimin kanssa, jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi, kehittää ohjelmiston toimintalogiikkaa, käyttää versionhallintaa, julkaisee ohjelman tuotantoympäristöön, käyttää ohjelmistokomponenttikirjaston tärkeimpiä toimintoja ja työkaluja sekä suunnittelee, toteuttaa ja testaa ohjelmiston ohjelmistokomponenttikirjastoa käyttäen.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 48 – Viivasta putki ja mallin näkymät (23.–27.11.2026)
> Kirjaa: Kumpi osa valmistui ensin ja siirtyikö kamera viikolle 49, putkigeometrian rajoitteet ja sivumäärän rajaus selityspohjalla. Työnäytteet: putken kortin issuen numero ja sen Sovittu viikkopalaverissa -kommentin osoite (Kopioi osoite, issuen numero tai commitin tunnus, kohta Issuen kommentin osoite), kameran kortin issuen numero, kirjastot.md-commitin tunnus ja releasen v0.0.48 osoite. Kirjoita kohtaan Missä työnäyte on? nämä näyttömatriisin vaatimukset: testaa ohjelman toimintoja; tulkitsee suunnitelmia ja toteuttaa käyttöliittymän tai sen osia; tulkitsee suunnitelmia ja toteuttaa ohjelmiston toimintoja; sopii tehtävistä tiimin muiden jäsenten kanssa; jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi; kehittää ohjelmiston toimintalogiikkaa; käyttää versionhallintaa; julkaisee ohjelman tuotantoympäristöön; selvittää ohjelmistokomponenttikirjaston tarjoamat mahdollisuudet ja rajoitteet; käyttää ohjelmistokomponenttikirjaston tärkeimpiä toimintoja ja työkaluja; suunnittelee, toteuttaa ja testaa ohjelmiston ohjelmistokomponenttikirjastoa käyttäen.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 49 – Osien siirto, kierto ja skaalaus (30.11.–4.12.2026)
> Kirjaa: Pakollisen ytimen tilanne ja palaverin päätös, testin 15 tulos ja maailmamuunnoksen laskenta selityspohjalla. Työnäytteet: transformipaneelin kortin issuen numero ja sen Sovittu viikkopalaverissa -kommentin osoite (Kopioi osoite, issuen numero tai commitin tunnus, kohta Issuen kommentin osoite); pikanäppäinten kortin issuen numero; kameran kortin issuen numero, jos kamera siirtyi tälle viikolle; havaintoissuen numero, jos teit sen; README-commitin tunnus; suunnitelma.md-commitin tunnus, jos pakollinen ydin oli myöhässä; releasen v0.0.49 osoite. Kirjoita kohtaan Missä työnäyte on? nämä näyttömatriisin vaatimukset: testaa ohjelman toimintoja; tulkitsee suunnitelmia ja toteuttaa käyttöliittymän tai sen osia; tulkitsee suunnitelmia ja toteuttaa ohjelmiston toimintoja; sopii tehtävistä tiimin muiden jäsenten kanssa; jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi; kehittää ohjelmiston toimintalogiikkaa; käyttää versionhallintaa; julkaisee ohjelman tuotantoympäristöön; käyttää ohjelmistokomponenttikirjaston tärkeimpiä toimintoja ja työkaluja; suunnittelee, toteuttaa ja testaa ohjelmiston ohjelmistokomponenttikirjastoa käyttäen.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 50 – Kiertopisteen säätäminen (pivot) (7.–11.12.2026)
> Kirjaa: Pivotin syötteen tarkistus selityspohjalla ja testien 16–18 tulokset. Työnäytteet: rajapintatiedoston Pivotin_tarkistus.md commitin tunnus, tarkistuksen kortin issuen numero ja sen Sovittu viikkopalaverissa -kommentin osoite (Kopioi osoite, issuen numero tai commitin tunnus, kohta Issuen kommentin osoite), pivotin ja kenttien korttien issuenumerot ja releasen v0.0.50 osoite. Kirjoita kohtaan Missä työnäyte on? nämä näyttömatriisin vaatimukset: testaa ohjelman toimintoja; käyttää rakenteista ohjelmointia toteutuksissa; tulkitsee suunnitelmia ja toteuttaa käyttöliittymän tai sen osia; sopii tehtävistä tiimin muiden jäsenten kanssa; jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi; kehittää ohjelmiston toimintalogiikkaa; käyttää versionhallintaa; julkaisee ohjelman tuotantoympäristöön; käyttää ohjelmistokomponenttikirjaston tärkeimpiä toimintoja ja työkaluja; suunnittelee, toteuttaa ja testaa ohjelmiston ohjelmistokomponenttikirjastoa käyttäen.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 51 – Viennin aloitus ennen joululomaa (14.–17.12.2026)
> Kirjaa: Objektijaon rajapinta tiedostossa project-docs/Rajapinnat/Objektijako.md, testien 19 ja 20 odotetut tulokset, viennin kortin issuen numero, valitun havaintoissuen numero tai pyydetty vikatehtävä, tilatiedoston Seuraavana-rivit ja näyttömatriisin vaatimukset (rivien nimet): sopii tehtävistä tiimin muiden jäsenten kanssa; jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi; hyödyntää rajapintoja ja käsittelee tietoa; käyttää versionhallintaa. Viikon viimeinen työpäivä on torstai 17.12.: kirjoita kirjaus silloin.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 2 – Mallin vienti Blenderiin (OBJ) (11.–15.1.2027)
> Kirjaa: Ympäristön tarkistuksen ja testiajon tulokset loman jälkeen, objektijako selityspohjalla, viennin kortin issuen numero ja testit 19–20, havaintoissuen numero ja sen virheenkorjausketju 1, regressiotestin nimi, kuva project-docs/kuvat/obj-blenderissa.png, releasen v0.0.51 osoite ja näyttömatriisin vaatimukset (rivien nimet): etsii ja korjaa virheitä ohjelmakoodista; testaa ohjelman toimintoja; käyttää rakenteista ohjelmointia toteutuksissa; sopii tehtävistä tiimin muiden jäsenten kanssa; jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi; hyödyntää rajapintoja ja käsittelee tietoa; käyttää versionhallintaa; julkaisee ohjelman tuotantoympäristöön; suunnittelee, toteuttaa ja testaa ohjelmiston ohjelmistokomponenttikirjastoa käyttäen.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 3 – Tallennus ja ensimmäinen toimiva versio (18.–22.1.2027)
> Kirjaa: Avausfunktio selityspohjalla, tallennustavan valinta perusteluineen, oman mallisi tallennustiedoston koko, tallennuksen kortin issuen numero ja testit 21–22, tietoturva-arvion tärkein uhka eli se, jonka seuraus käyttäjälle olisi vakavin, ja sen peruste, releasen v0.1 osoite, käynnistyskokeilun issuen numero ja näyttömatriisin vaatimukset (rivien nimet): testaa ohjelman toimintoja; sopii tehtävistä tiimin muiden jäsenten kanssa; jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi; valitsee ohjelmistoon sopivan tietovaraston; toteuttaa yhteyden tietovarastoon; hyödyntää rajapintoja ja käsittelee tietoa; arvioi ohjelmiston tietoturvaa; käyttää versionhallintaa; julkaisee ohjelman tuotantoympäristöön; suunnittelee, toteuttaa ja testaa ohjelmiston ohjelmistokomponenttikirjastoa käyttäen; julkaisee ohjelmiston asiakkaan ympäristöön.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 4 – Asiakkaat kokeilevat ensimmäistä versiota (25.–29.1.2027)
> Kirjaa: Asiakkaiden tärkein havainto eli prioriteetin 1 muutostoive tiivistettynä, oma tulkintasi erikseen, katselmoinnin havaintoissueiden numerot, issue, jossa on kommentti Sovittu viikkopalaverissa, tilatiedoston Seuraavana-kohdan issue ja näyttömatriisin vaatimukset (rivien nimet): sopii tehtävistä tiimin muiden jäsenten kanssa; arvioi ratkaisujen toimivuuden yhdessä tiimin kanssa; viestii tekniset asiat asiakaslähtöisesti; osallistuu version katselmointiin; asettaa kehitystiimin kanssa toteutettavat toiminnot tärkeysjärjestykseen. Kirjoita kirjaus perjantaina.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 5 – Parannusten järjestys ja ensimmäinen korjaus (1.–5.2.2027)
> Kirjaa: Ympäristön tarkistuksen ja testiajon tulokset, krediittien lähtötilanne, tärkeän jatkon järjestys tuntiarvioineen (suunnitelmassa ja issueissa), palaverin arvio pakollisen ytimen eli MVP:n ratkaisuista, korjauksen kortin issuen numero ja sana Sovittu-kommentti sekä korjauksen commitin tunnus. Kirjoita kohtaan Missä työnäyte on? nämä näyttömatriisin vaatimukset: käyttää ohjelmointieditoria tai kehitysympäristöä, sopii tehtävistä tiimin muiden jäsenten kanssa, arvioi ratkaisujen toimivuuden yhdessä tiimin kanssa, asettaa kehitystiimin kanssa toteutettavat toiminnot tärkeysjärjestykseen, jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi sekä suunnittelee ja arvioi kehitystiimin kanssa tehtävien toteuttamista.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 6 – Muokatun piirroksen päivittäminen (8.–12.2.2027)
> Kirjaa: Tunnistustapa ja sen perustelu, kortin issuen numero ja sana Sovittu-kommentti, testin 23 tulos, pull requestin linkki ja päivityksen tunnistusfunktio selityspohjalla. Kirjoita kohtaan Missä työnäyte on? nämä näyttömatriisin vaatimukset: testaa ohjelman toimintoja, sopii tehtävistä tiimin muiden jäsenten kanssa, etsii ratkaisuvaihtoehtoja ja ratkoo ongelmia yhdessä tiimin kanssa, jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi, kehittää ohjelmiston toimintalogiikkaa sekä liittää ohjelman osan olemassa olevaan versioon.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 7 – Puutteet ja sovitut parannukset (15.–19.2.2027)
> Kirjaa: Mitä teit ja miksi juuri sen, kortin issuen numero ja sana Sovittu-kommentti, kortin testin tulos (testi 24 tai rästin testi), pull requestin linkki, jos teit haaran, sekä virheenkorjausketju 2. Kirjoita kohtaan Missä työnäyte on? nämä näyttömatriisin vaatimukset: etsii ja korjaa virheitä ohjelmakoodista, testaa ohjelman toimintoja, sopii tehtävistä tiimin muiden jäsenten kanssa sekä jakaa kehitystiimin kanssa toteutettavat toiminnot tehtäviksi.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 9 – Selkeät säätimet ja näppäimistökäyttö (1.–5.3.2027)
> Kirjaa: FastPassin tulokset ennen ja jälkeen, testit 25–26, kortin issuen kommentti Sovittu viikkopalaverissa ja näyttömatriisin vaatimukset: testaa ohjelman toimintoja, tulkitsee suunnitelmia ja toteuttaa käyttöliittymän tai sen osia sekä sopii tehtävistä tiimin muiden jäsenten kanssa.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 10 – Julkaisun kokeilu toisella koneella (8.–12.3.2027)
> Kirjaa: Julkaisutestin tärkein epäröintikohta roolilla kirjattuna, ohjeeseen tehty korjaus, tagi v1.0-rc1, issuen kommentti Sovittu viikkopalaverissa ja näyttömatriisin vaatimukset: dokumentoi ohjelmiston sovitulla tavalla, viestii tekniset asiat asiakaslähtöisesti, julkaisee ohjelman tuotantoympäristöön, käyttää versionhallintaa ja sopii tehtävistä tiimin muiden jäsenten kanssa.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 11 – Valmis sovellus v1.0 (15.–19.3.2027)
> Kirjaa: Virheenkorjausketju 3, asiakkaiden vahvistus, korjauskortin issuen kommentti Sovittu viikkopalaverissa ja näyttömatriisin vaatimukset: etsii ja korjaa virheitä ohjelmakoodista, käyttää versionhallintaa, julkaisee ohjelman tuotantoympäristöön, julkaisee ohjelmiston asiakkaan ympäristöön ja sopii tehtävistä tiimin muiden jäsenten kanssa.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?

## Vko 12 – Projektin esittely ja luovutus (22.–26.3.2027)
> Kirjaa: Repositoryn osoite ja aineiston linkit, demon viisi osaa ja niihin valitut työnäytteet (funktio, havaintoissue ja kortin issue), demon kesto ja harjoittelun havainto, itsearvioinnin kolmen tilanteen päivät ja issue-numerot, itsearvioinnin lähetyspäivä, lause luovutetaan tänään 26.3.2027 sekä näyttömatriisin vaatimus: arvioi omaa toimintaa tiimin jäsenenä.

### Mitä tein ja miten?

### Miksi tein näin?

### Missä työnäyte on?
